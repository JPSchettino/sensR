
if(require(testthat) && require(sensR)) {
    test_check("sensR")
}
